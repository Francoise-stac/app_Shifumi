# app_Shifumi
Le but de ce brief est de développer une application Web permettant de jouer au ShiFuMi contre un adversaire logiciel. Dans cette première version, le mode d'interaction avec l'application se fera via le click souris.
